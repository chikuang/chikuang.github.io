Topics of Statistical Learning

Run a lab in a fresh R session, for example:
Rscript --vanilla labs/03-pu-learning.R

Required calculations use base R. Optional clusterpval and KmeansInference calculations run when installed. See the course workflow and chapter notes for assumptions and installation links.

lab-outputs contains executed stdout and an execution manifest. The code is the source of the results; recorded outputs are reference evidence, not a substitute for execution.

Course: https://chikuang.github.io/teaching/statistical-learning/
