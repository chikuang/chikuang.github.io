::::{container} cell_output

```text
Known class-conditional transition matrix:
          recorded
true       positive negative
  positive      0.7      0.3
  negative      0.1      0.9

Thresholds selected using each training criterion:
            method threshold held_out_error held_out_MCSE
        noisy_risk      0.94        0.37952     0.0015346
    corrected_risk     -0.24        0.30695     0.0014585
 oracle_clean_risk     -0.14        0.30293     0.0014532

The oracle clean criterion uses hidden training labels only as a benchmark.
Held-out labels are used for assessment, never threshold selection.

Corrected losses for a positive decision:
 recorded_label corrected_loss
       positive      -0.500000
       negative       1.166667
Recovered expected losses conditional on the true class:
positive negative 
       0        1 

Complementary-label corrected risk for a prediction of A:
 true_class expected_corrected_loss
          A                       0
          B                       1
          C                       1
```

```{image} ../_static/figures/02-weak-supervision.png
:alt: Executed R experiment for weak supervision; numerical results are printed above.
:width: 100%
```

::::
