::::{container} cell_output

```text
Lloyd trace for one Gaussian cloud
 iteration within_sum_squares
         1             66.109
         2             65.540
         3             63.685
         4             61.906
         5             61.432
         6             61.432
Objective never increases: TRUE 
Converged: TRUE 
Pairwise co-membership agreement across two fixed initializations: 0.5192 

Base-R fixed-initialization Lloyd: global-null diagnostic
                            method runs rejection_rate monte_carlo_se mc_lower mc_upper
 Naive Wald after Lloyd clustering  400              1              0   0.9908        1
This diagnostic is not a selective-inference procedure.
mc_lower/mc_upper are exact 95% binomial Monte Carlo intervals.
An observed rate of 1 has plug-in MCSE 0 but still has binomial uncertainty.

Authors' path-conditioned method EXECUTED; KmeansInference version 0.1.0 
Successful finite p-values: 60 of 60 
                        method runs rejection_rate monte_carlo_se mc_lower mc_upper
     Authors' algorithm: naive   60        1.00000        0.00000 0.940371   1.0000
 Authors' algorithm: selective   60        0.03333        0.02317 0.004063   0.1153
The paired comparison uses the same authors' algorithm and seed.
Sixty repetitions are a demonstration, not a high-precision size study.
```

```{image} ../_static/figures/13-kmeans-inference.png
:alt: Executed R experiment for kmeans inference; numerical results are printed above.
:width: 100%
```

::::
