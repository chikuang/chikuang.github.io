::::{container} cell_output

```text
Working logistic model with repeated observations from each judge:
            estimate iid_se judge_sandwich_se judge_bootstrap_se
relevance     0.6684 0.0831            0.1047             0.1010
conciseness   0.3127 0.0776            0.0848             0.0786
order         0.2026 0.0754            0.1846             0.1906

Bootstrap usable/flagged replicates: 150 / 0 
The working coefficients summarize a marginal logistic approximation.
They need not equal the conditional coefficients used to generate the data.
Judge-level resampling assumes independent judges; it is not a two-way bootstrap.

Finite-action policy and reference probabilities:
  action reference policy
1      1       0.5 0.2680
2      2       0.3 0.2847
3      3       0.2 0.4473
Preference probability from rewards / policy log ratios:
   reward log_ratio 
 0.731059  0.731059
```

```{image} ../_static/figures/07-contextual-preferences.png
:alt: Experiment results for contextual preferences; numerical results are printed above.
:width: 100%
```

::::
