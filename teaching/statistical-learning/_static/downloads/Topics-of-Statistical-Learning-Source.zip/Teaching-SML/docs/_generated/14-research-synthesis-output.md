::::{container} cell_output

```text
Known sigma = 1; Ward discovery clustering; inference feature = 1
Coverage target: the actual selected groups' average underlying means.
        scenario tau coverage coverage_mcse mean_CI_length selected_RMSE null_rejection group_agreement
     Global null 0.2   0.9675      0.008866          1.203        0.2899         0.0325              NA
     Global null 0.5   0.9400      0.011874          1.536        0.3844         0.0600              NA
     Global null 0.8   0.9475      0.011152          2.429        0.6389         0.0525              NA
 Separated means 0.2   0.9625      0.009499          1.210        0.2992             NA          0.5560
 Separated means 0.5   0.9700      0.008529          1.510        0.3592             NA          0.6423
 Separated means 0.8   0.9600      0.009798          2.360        0.5772             NA          0.7178
NA entries mark quantities deliberately not interpreted in that scenario.

Scale sensitivity at discovery fraction 0.5; true sigma remains 1
 assumed_sigma component_covariance null_rejection monte_carlo_se
           0.7                 0.51         0.4575        0.02491
           1.0                 0.00         0.0600        0.01187
           1.3                -0.69         0.1425        0.01748
Only assumed_sigma = 1 is covered by the independence derivation.
```

```{image} ../_static/figures/14-research-synthesis.png
:alt: Experiment results for research synthesis; numerical results are printed above.
:width: 100%
```

::::
