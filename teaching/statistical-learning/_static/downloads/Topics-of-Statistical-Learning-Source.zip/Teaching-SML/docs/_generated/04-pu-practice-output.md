::::{container} cell_output

```text
PART A: fixed-rule logistic risk
Numerically integrated reference risk: 0.1623882 
 estimator    mean     bias      SD bias_MCSE     MSE
       uPU 0.18347 0.021085 0.44787 0.0141629 0.20083
      nnPU 0.30958 0.147196 0.30515 0.0096496 0.11469
Fraction with negative estimated negative-class contribution: 0.402 

PART B: flexible fitted rules, assessed on independent labelled data
 method training_positive_part training_negative_part test_log_loss test_error
    uPU              0.0645723            -1.6771e+00       0.34373   0.131100
   nnPU              0.0045449            -1.3524e-10       0.31576   0.093567
 test_error_MCSE optimizer_code
       0.0019486              0
       0.0016814              0

Optimizer code 0 indicates numerical convergence, not global optimality.
The score bounds, regularizer, and three starts are shared by both methods.
A single fitted-rule comparison is illustrative; repeat training for a method comparison.
```

```{image} ../_static/figures/04-pu-practice.png
:alt: Executed R experiment for pu practice; numerical results are printed above.
:width: 100%
```

::::
