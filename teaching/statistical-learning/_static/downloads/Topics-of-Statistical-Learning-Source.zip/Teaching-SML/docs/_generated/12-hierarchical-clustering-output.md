::::{container} cell_output

```text
Global null: independent N_2(0, I) observations; fixed K = 2
                      method runs rejection_rate monte_carlo_se mc_lower mc_upper
 Fixed groups: ordinary Wald  500          0.068       0.011258  0.04755  0.09373
  Learned groups: naive Wald  500          0.980       0.006261  0.96353  0.99037

Example 12.1: naive p-value for squared standardized contrast 7.2 = 0.0273237 
mc_lower/mc_upper: exact 95% binomial intervals for simulation rejection probabilities.

Authors' exact procedure EXECUTED; clusterpval version 1.0.1 
Successful finite p-values: 100 of 100 
                        method runs rejection_rate monte_carlo_se mc_lower mc_upper
 Known-variance selective test  100           0.06        0.02375  0.02233    0.126
The selective Monte Carlo check is small; its standard error matters.
```

```{image} ../_static/figures/12-hierarchical-clustering.png
:alt: Executed R experiment for hierarchical clustering; numerical results are printed above.
:width: 100%
```

::::
