::::{container} cell_output

```text
Example 11.1
 winner statistic threshold    naive selective
      1       2.4       1.7 0.016395   0.18394

Simulation calibration (alpha = 0.05)
                             procedure repetitions rejection_rate monte_carlo_se
      Global null: naive selected test       10000        0.64010       0.004800
     Global null: exact selective test       10000        0.05220       0.002224
 One signal: selected null coordinates        3683        0.05539       0.003769

Theoretical global-null naive rejection rate: 0.641514 
Known variance = 1; coordinates independent; no estimated nuisance parameters.
```

```{image} ../_static/figures/11-selective-inference.png
:alt: Experiment results for selective inference; numerical results are printed above.
:width: 100%
```

::::
