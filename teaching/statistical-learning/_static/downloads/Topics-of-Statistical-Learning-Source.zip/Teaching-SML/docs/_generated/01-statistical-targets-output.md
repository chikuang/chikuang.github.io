::::{container} cell_output

```text
Independent training replications: 200 
Training observations per replication: 50 
Irreducible variance: 0.49 
Target: X uniform on [-1, 1]; squared prediction error.

 degree mean_training_MSE mean_target_risk risk_MCSE mean_optimism
      1           0.48989          0.53407 0.0016039      0.044178
      2           0.46359          0.52189 0.0016984      0.058303
      8           0.40349          0.84472 0.0778877      0.441230
 optimism_MCSE
     0.0073334
     0.0070737
     0.0780512

Target risks use the known simulation mean and a midpoint integration grid.
MCSE describes uncertainty across repeated training datasets.
It is not a confidence interval for an individual fitted model's risk.
```

```{image} ../_static/figures/01-statistical-targets.png
:alt: Executed R experiment for statistical targets; numerical results are printed above.
:width: 100%
```

::::
