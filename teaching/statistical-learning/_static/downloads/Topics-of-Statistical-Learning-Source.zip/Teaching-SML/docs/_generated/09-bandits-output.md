::::{container} cell_output

```text
Stationary Bernoulli bandits; fixed horizon, all arms sampled once first:
            mean_regret regret_mcse mean_reward optimal_fraction
uniform        225.1350      0.6526      0.4613           0.2503
epsilon_0.1     47.6945      3.5296      0.6103           0.7338
ucb             70.3205      1.1183      0.5908           0.6587

Paired UCB minus epsilon-greedy pseudo-regret (negative favours UCB):
mean_difference            mcse 
        22.6260          3.7281 
Finite-horizon rankings can depend on gaps, tuning and horizon.
The simulator knows means for scoring; the policies do not.
```

```{image} ../_static/figures/09-bandits.png
:alt: Executed R experiment for bandits; numerical results are printed above.
:width: 100%
```

::::
