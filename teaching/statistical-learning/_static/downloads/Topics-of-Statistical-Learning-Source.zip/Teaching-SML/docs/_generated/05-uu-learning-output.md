::::{container} cell_output

```text
Target prior: 0.5 ; threshold: 0.2 
Independent samples per replication: 500 from each mixture
Replications: 1000 ; analytic target risk: 0.1634625 

   a    b prior_gap mean_risk        bias empirical_SD exact_SD mean_MCSE
 0.7 0.30      0.40   0.16297 -0.00048753     0.038230 0.037876 0.0012089
 0.7 0.50      0.20   0.15915 -0.00431253     0.077636 0.078280 0.0024551
 0.7 0.65      0.05   0.17360  0.01013747     0.309276 0.312986 0.0097802
 0.7 0.69      0.01   0.25130  0.08783747     1.495712 1.559242 0.0472986
 fraction_outside_0_1
                0.000
                0.018
                0.296
                0.724

Common-class-conditional assumption violated in mixture 2:
 target_risk misspecified_limit simulated_mean mean_MCSE asymptotic_bias
     0.16346            0.22019        0.21973 0.0011821        0.056732

The target population still uses positive mean 1 and negative mean -1.
Larger samples reduce variability around the misspecified limit, not its bias.
```

```{image} ../_static/figures/05-uu-learning.png
:alt: Experiment results for uu learning; numerical results are printed above.
:width: 100%
```

::::
