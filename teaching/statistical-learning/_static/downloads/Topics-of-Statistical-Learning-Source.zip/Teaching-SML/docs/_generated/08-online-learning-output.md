::::{container} cell_output

```text
Full-information losses; mixture loss is expected loss under sampled experts:
                       total_loss fixed_regret two_segment_regret
uniform                   240.000       20.000            123.000
hedge                     231.052       11.052            114.052
known_boundary_restart    139.536      -80.464             22.536

The restart policy is given the true change boundary; it is an oracle illustration.
A negative fixed-comparator regret is possible because the learner can change weights.
Hedge weights before rounds 1, 400, 401 and 800:
       [,1]   [,2]   [,3]
[1,] 0.3333 0.3333 0.3333
[2,] 0.9953 0.0047 0.0000
[3,] 0.9953 0.0047 0.0000
[4,] 0.1081 0.8799 0.0120

Projected OGD, fixed-comparator regret and the deterministic upper bound:
   regret     bound step_size 
     23.2      40.0       0.1
```

```{image} ../_static/figures/08-online-learning.png
:alt: Executed R experiment for online learning; numerical results are printed above.
:width: 100%
```

::::
