::::{container} cell_output

```text
Target prior: 0.3 ; sample sizes P = 250 , U = 1500 
Positive fraction in the assembled training data: 0.1428571 (not the target prior)

          method intercept   slope test_error test_error_MCSE test_log_loss
           naive  -1.63544 0.61106    0.29092       0.0020312       0.49859
              PU  -0.66237 1.46182    0.13840       0.0015443       0.33206
 labelled_oracle  -0.80028 1.71235    0.13836       0.0015441       0.32360
           Bayes  -0.84730 2.00000    0.13852       0.0015449       0.32073
 test_Brier
    0.17327
    0.10228
    0.10066
    0.10007

Separate SCAR population sample:
                        quantity empirical theoretical
         Observed-label fraction   0.12218     0.12000
     Positive fraction among S=0   0.20510     0.20455
 Feature mean in full population  -0.39511    -0.40000
          Feature mean among S=0  -0.58891    -0.59091

The S=0 subset is not the full target feature marginal.
```

```{image} ../_static/figures/03-pu-learning.png
:alt: Executed R experiment for pu learning; numerical results are printed above.
:width: 100%
```

::::
