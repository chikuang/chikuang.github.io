::::{container} cell_output

```text
Bradley-Terry preference matrix:
      [,1]  [,2]  [,3]  [,4]  [,5]
[1,] 0.500 0.378 0.310 0.231 0.154
[2,] 0.622 0.500 0.426 0.332 0.231
[3,] 0.690 0.574 0.500 0.401 0.289
[4,] 0.769 0.668 0.599 0.500 0.378
[5,] 0.846 0.769 0.711 0.622 0.500
Condorcet winner: 5 
Borda scores:
[1] 0.268 0.403 0.489 0.603 0.737

Strong pseudo-regret uses half the sum of the two winner gaps:
     balanced_regret explore_commit_regret selected_correctly
mean        113.6962               34.2002             0.9000
mcse          0.0000                1.4427             0.0246
Explore-then-commit is a teaching baseline, not a claim of optimal regret.

A cyclic matrix (row item beats column item):
     [,1] [,2] [,3]
[1,] 0.50 0.75 0.40
[2,] 0.25 0.50 0.65
[3,] 0.60 0.35 0.50
Condorcet winners: none 
Borda scores and Borda winner:
[1] 0.575 0.450 0.475
[1] 1
A Condorcet-regret target is unavailable for this cyclic example.
```

```{image} ../_static/figures/10-duelling-bandits.png
:alt: Executed R experiment for duelling bandits; numerical results are printed above.
:width: 100%
```

::::
