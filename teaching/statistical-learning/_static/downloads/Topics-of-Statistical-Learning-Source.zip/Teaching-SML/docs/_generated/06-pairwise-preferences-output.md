::::{container} cell_output

```text
Comparison-matrix ranks; a connected K-item design needs rank K-1:
    complete        chain disconnected 
           5            5            4 

Local standard error for theta_1 - theta_6 at the generating strengths:
complete    chain 
  0.2185   0.4152 

Fixed-design simulation; coverage is estimated, not guaranteed:
         usable flagged    bias   rmse mean_se coverage coverage_mcse
complete    150       0 -0.0206 0.2004  0.2200     0.96         0.016
chain       150       0 -0.0025 0.4139  0.4171     0.96         0.016

The disconnected design is not fitted: the endpoint contrast is unidentified.
Flagged fits are disclosed; reported simulation summaries use the usable fits.

A beats B, B beats C: undirected graph connected, directed wins strongly connected?
[1] FALSE
```

```{image} ../_static/figures/06-pairwise-preferences.png
:alt: Executed R experiment for pairwise preferences; numerical results are printed above.
:width: 100%
```

::::
