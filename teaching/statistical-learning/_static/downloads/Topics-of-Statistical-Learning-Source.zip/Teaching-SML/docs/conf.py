"""Python configuration for the Topics of Statistical Learning course book."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent / "_ext"))

project = "Topics of Statistical Learning"
author = "Chi-Kuang Yeh"
copyright_year = "2026"
copyright = f"{copyright_year}, {author}"
extensions = ["myst_parser", "sphinx_copybutton", "sphinx_design", "code_folding", "chapter_equations", "concept_boxes"]
exclude_patterns = ["_build", "_generated/**", "_static/**"]
master_doc = "index"
language = "en"
myst_enable_extensions = ["dollarmath", "amsmath", "colon_fence", "deflist"]
myst_heading_anchors = 4
nb_execution_mode = "cache"
nb_execution_timeout = 120
nb_execution_raise_on_error = True
nb_execution_show_tb = True
nb_execution_in_temp = True
html_theme = "sphinx_book_theme"
html_title = project
html_static_path = ["_static"]
html_css_files = ["course.css", "statistical-learning.css"]
html_js_files = ["learning-controls.js", "course-demos.js"]
templates_path = ["_templates"]
html_baseurl = "https://chikuang.github.io/teaching/statistical-learning/"
html_context = {
    "default_mode": "auto",
    "course_pdf": "Topics-of-Statistical-Learning.pdf",
    "copyright_year": copyright_year,
    "author_url": "https://chikuang.github.io/",
}
html_theme_options = {
    # The book theme has its own header; avoid duplicate mobile toggle buttons.
    "navbar_persistent": [],
    "article_header_end": ["course-pdf-button.html", "article-header-buttons.html"],
    "pygments_light_style": "friendly",
    "pygments_dark_style": "monokai",
    "repository_url": "https://github.com/chikuang/Teaching-SML",
    "repository_branch": "main",
    "path_to_docs": "docs",
    "use_repository_button": True,
    "use_source_button": True,
    "use_download_button": False,
    "show_navbar_depth": 1,
    "show_toc_level": 2,
    "navigation_depth": 3,
    "home_page_in_toc": True,
    "logo": {"text": "Topics of Statistical Learning"},
    "footer_content_items": ["copyright.html", "last-updated.html", "extra-footer.html"],
    "extra_footer": "Topics of Statistical Learning",
}
html_show_sourcelink = True
html_show_sphinx = False
html_last_updated_fmt = "%B %d, %Y"
numfig = True
# The chapter_equations extension gives labeled equations chapter-local numbers.
math_numfig = True
math_number_all = False
numfig_secnum_depth = 0
pygments_style = "friendly"
html_copy_source = True

# The same chapter tree and executed examples form the downloadable course book.
latex_engine = "xelatex"
latex_documents = [("index", "Topics-of-Statistical-Learning.tex", project, author, "manual", False)]
latex_show_urls = "no"
latex_show_pagerefs = True
latex_domain_indices = False
latex_elements = {
    "fontpkg": r"\setmainfont{DejaVuSerif.ttf}[BoldFont=DejaVuSerif-Bold.ttf,ItalicFont=DejaVuSerif-Italic.ttf,BoldItalicFont=DejaVuSerif-BoldItalic.ttf]\setsansfont{DejaVuSans.ttf}[BoldFont=DejaVuSans-Bold.ttf,ItalicFont=DejaVuSans-Oblique.ttf,BoldItalicFont=DejaVuSans-BoldOblique.ttf]\setmonofont{DejaVuSansMono.ttf}[Scale=0.85,BoldFont=DejaVuSansMono-Bold.ttf,ItalicFont=DejaVuSansMono-Oblique.ttf,BoldItalicFont=DejaVuSansMono-BoldOblique.ttf]",
    "papersize": "letterpaper",
    "pointsize": "11pt",
    "figure_align": "H",
    "extraclassoptions": "oneside,openany",
    "geometry": r"\usepackage[margin=1in,headheight=26pt]{geometry}",
    "fncychap": "",
    "makeindex": "",
    "printindex": "",
    "tableofcontents": r"\renewcommand{\contentsname}{Contents}\tableofcontents",
    "sphinxsetup": r"VerbatimColor={RGB}{247,248,250},VerbatimBorderColor={RGB}{220,225,230},TitleColor={RGB}{48,56,66},InnerLinkColor={RGB}{162,0,110},OuterLinkColor={RGB}{162,0,110}",
    "preamble": r"""
\usepackage[most]{tcolorbox}
\usepackage{float}
\definecolor{coursecore}{HTML}{9B1B68}
\definecolor{coursemethod}{HTML}{176B72}
\definecolor{courseboundary}{HTML}{966400}
\newtcolorbox{coursebox}[2]{enhanced,breakable,
  colback=course#1!5!white,colframe=course#1,
  colbacktitle=course#1!12!white,coltitle=course#1!85!black,
  fonttitle=\bfseries\sffamily,title={#2},
  boxrule=0.5pt,leftrule=2.5pt,arc=2pt,
  left=9pt,right=9pt,top=7pt,bottom=7pt,
  before skip=12pt,after skip=12pt}
\setcounter{secnumdepth}{-1}
\setcounter{tocdepth}{1}
\makeatletter
\renewcommand{\@pnumwidth}{2em}
\renewcommand{\@tocrmarg}{3em}
\makeatother
% Keep internal equation anchors unique; chapter_equations sets printed numbers.
\counterwithout{equation}{chapter}
\fvset{fontsize=\small}
\setlength{\emergencystretch}{3em}
% Long appendix section names collide with page numbers in Sphinx's default footer.
\fancypagestyle{normal}{
  \fancyhf{}
  \fancyhead[R]{\small\sffamily Topics of Statistical Learning}
  \fancyfoot[L]{\small\sffamily Statistical Learning}
  \fancyfoot[R]{\small\sffamily\thepage}
  \renewcommand{\headrulewidth}{0.4pt}
  \renewcommand{\footrulewidth}{0.4pt}
}
""",
}

